const API_URL = "https://api.sheetbest.com/sheets/03780314-1384-465b-92d2-f2650505093a";

function startScanner() {
  Html5Qrcode.getCameras()
    .then(cameras => {
      if (cameras && cameras.length > 0) {
        const qrReader = new Html5Qrcode("qr-reader");
        const cameraId = cameras[0].id;

        qrReader.start(
          cameraId,
          { fps: 10, qrbox: 250 },
          (decodedText) => {
            qrReader.stop().then(() => {
              document.getElementById("qr-reader").innerHTML = "";
            });

            fetch(API_URL)
              .then(res => res.json())
              .then(data => {
                const match = data.find(item =>
                  item["PRODUCT CODE"]?.trim() === decodedText.trim()
                );
                if (match) {
                  document.getElementById("product-name").textContent = match["PRODUCT"];
                  document.getElementById("product-price").textContent = match["PRICE"];
                } else {
                  alert("No matching item found in the Sheet.");
                }
              });
          },
          (err) => {
            console.warn("QR Scan Error: ", err);
          }
        );
      } else {
        alert("No cameras found on this device.");
      }
    })
    .catch(err => {
      alert("Camera access denied or not available.");
      console.error("Camera Error:", err);
    });
}

function acceptProduct() {
  const product = document.getElementById("product-name").textContent;
  const price = document.getElementById("product-price").textContent;
  if (product === "-" || price === "-") return;
  const today = new Date().toLocaleDateString();
  const table = document.querySelector("#scan-history tbody");
  let existing = [...table.rows].find(row => row.cells[0].textContent === today && row.cells[1].textContent === product);
  if (existing) {
    existing.cells[3].textContent = parseInt(existing.cells[3].textContent) + 1;
  } else {
    const row = table.insertRow();
    row.insertCell(0).textContent = today;
    row.insertCell(1).textContent = product;
    row.insertCell(2).textContent = price;
    row.insertCell(3).textContent = 1;
  }
}

function rejectProduct() {
  document.getElementById("product-name").textContent = "-";
  document.getElementById("product-price").textContent = "-";
}

function clearHistory() {
  if (confirm("Are you sure you want to clear all history?")) {
    document.querySelector("#scan-history tbody").innerHTML = "";
  }
}

function exportCSV() {
  let csv = "Date,Product,Price,Quantity\n";
  document.querySelectorAll("#scan-history tbody tr").forEach(row => {
    csv += [...row.cells].map(cell => cell.textContent).join(",") + "\n";
  });
  const blob = new Blob([csv], { type: "text/csv" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "scan_history.csv";
  link.click();
}

function filterByDate() {
  const selected = document.getElementById("filter-date").value;
  const rows = document.querySelectorAll("#scan-history tbody tr");
  rows.forEach(row => {
    row.style.display = row.cells[0].textContent === selected ? "" : "none";
  });
}

function resetFilter() {
  document.getElementById("filter-date").value = "";
  document.querySelectorAll("#scan-history tbody tr").forEach(row => {
    row.style.display = "";
  });
}